clc

tic
run mon_fig_hfi

run mon_baseline
run mon_hfi_baseline

run mon_einf
run mon_hfi_einf

run mon_lint
run mon_hfi_lint

run mon_m3
run mon_hfi_m3

run mon_fig_eonia
run mon_further
run mon_short
run mon_sr14
run mon_sr4mr
run mon_conj
run mon_gdp
run mon_core
toc
